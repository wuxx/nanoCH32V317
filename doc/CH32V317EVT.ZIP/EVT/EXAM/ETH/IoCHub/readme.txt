IoCHub（Internet of Chip Hub）是一种能自适应广域网、局域网的透明直传解决方案。用户仅需调用一套接口，就能在无需申请固定IP或域名的情况下实现数据高效、安全、稳定的点对点透传，为MCU接口实现快速连接入网、稳定高效透传提供帮助。
关于IoCHub多平台开发资料请到我们网站上查询：
https://www.wch.cn/downloads/WCHIoCHubLib_MultiOS_ZIP.html

Lib: IoCHub库文件夹；
IoCHub_Demo：依据IoCHub MCU库，实现MCU与MCU、MCU与系统平台之间点对点传输，通过内置AT指令实现IoCHub在MCU上的基础功能演示。AT指令使用串口1（PA9/PA10）,波特率115200；